import logging
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from framefox.core.events.decorator.dispatch_event import DispatchEvent
from framefox.core.security.handlers.firewall_handler import FirewallHandler


class FirewallMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, settings):
        super().__init__(app)
        self.settings = settings
        self.logger = logging.getLogger("FIREWALL")
        self.handler = FirewallHandler(
            logger=self.logger,
            settings=settings,
        )

    @DispatchEvent(event_before="auth.auth_attempt", event_after="auth.auth_result")
    async def dispatch(self, request: Request, call_next):
        """
        Main middleware to handle authentication and authorization.
        """
        if self.settings.access_control:
            auth_response = await self.handler.handle_authentication(request, call_next)
            if auth_response:
                return auth_response
            return await self.handler.handle_authorization(request, call_next)
        else:
            self.logger.info("No access control rules defined.")

        return await call_next(request)
